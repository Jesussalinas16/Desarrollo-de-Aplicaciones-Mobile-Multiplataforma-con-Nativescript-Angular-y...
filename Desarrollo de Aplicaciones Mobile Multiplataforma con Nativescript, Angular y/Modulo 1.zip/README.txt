Proyecto NativeScript Angular - Drawer Navigation

Este proyecto está preparado como base para la tarea.

Para usarlo:
1. Descomprimir el archivo ZIP.
2. Abrir la carpeta en Visual Studio Code.
3. Ejecutar:
   npm install
4. Ejecutar en Android:
   ns run android

Incluye:
- Proyecto basado en template drawer navigation Angular.
- Módulo nuevo: productos.
- Dos componentes nuevos.
- Routing propio del módulo productos.
- Servicio global con inyección de dependencias.
- Lista usando ngFor.
- Estilos separados para Android e iOS.
- Carpeta App_Resources con espacio para ícono personalizado.
- Código TypeScript que detecta Android.
