import { Injectable } from '@angular/core';

export interface Producto {
  nombre: string;
  precio: number;
  categoria: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
  obtenerProductos(): Producto[] {
    return [
      { nombre: 'Laptop', precio: 15000, categoria: 'Tecnología' },
      { nombre: 'Mouse', precio: 350, categoria: 'Accesorio' },
      { nombre: 'Teclado', precio: 700, categoria: 'Accesorio' },
      { nombre: 'Audífonos', precio: 950, categoria: 'Audio' }
    ];
  }
}
