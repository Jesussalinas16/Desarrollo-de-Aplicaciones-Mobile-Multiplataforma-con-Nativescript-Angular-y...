import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-productos-detalle',
  templateUrl: './productos-detalle.component.html'
})
export class ProductosDetalleComponent implements OnInit {
  nombre = '';

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.nombre = this.route.snapshot.params['nombre'];
  }
}
