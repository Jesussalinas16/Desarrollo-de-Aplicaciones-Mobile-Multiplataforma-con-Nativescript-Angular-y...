import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { NativeScriptCommonModule } from '@nativescript/angular';
import { ProductosRoutingModule } from './productos-routing.module';
import { ProductosListaComponent } from './productos-lista/productos-lista.component';
import { ProductosDetalleComponent } from './productos-detalle/productos-detalle.component';

@NgModule({
  imports: [
    NativeScriptCommonModule,
    ProductosRoutingModule
  ],
  declarations: [
    ProductosListaComponent,
    ProductosDetalleComponent
  ],
  schemas: [NO_ERRORS_SCHEMA]
})
export class ProductosModule {}
