import { Component, OnInit } from '@angular/core';
import { RouterExtensions } from '@nativescript/angular';
import { isAndroid } from '@nativescript/core';
import { Producto, ProductosService } from '../../../services/productos.service';

@Component({
  selector: 'app-productos-lista',
  templateUrl: './productos-lista.component.html',
  styleUrls: ['./productos-lista.component.css']
})
export class ProductosListaComponent implements OnInit {
  productos: Producto[] = [];
  mensajeSistema = 'Sistema detectado: otro sistema';

  constructor(
    private productosService: ProductosService,
    private routerExtensions: RouterExtensions
  ) {}

  ngOnInit(): void {
    this.productos = this.productosService.obtenerProductos();

    if (isAndroid) {
      this.mensajeSistema = 'Sistema detectado: Android';
    }
  }

  verDetalle(producto: Producto): void {
    this.routerExtensions.navigate(['/productos/detalle', producto.nombre]);
  }
}
