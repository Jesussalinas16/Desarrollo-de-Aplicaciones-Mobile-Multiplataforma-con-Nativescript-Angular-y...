import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';
import { NativeScriptRouterModule } from '@nativescript/angular';
import { ProductosListaComponent } from './productos-lista/productos-lista.component';
import { ProductosDetalleComponent } from './productos-detalle/productos-detalle.component';

const routes: Routes = [
  { path: '', component: ProductosListaComponent },
  { path: 'detalle/:nombre', component: ProductosDetalleComponent }
];

@NgModule({
  imports: [NativeScriptRouterModule.forChild(routes)],
  exports: [NativeScriptRouterModule]
})
export class ProductosRoutingModule {}
