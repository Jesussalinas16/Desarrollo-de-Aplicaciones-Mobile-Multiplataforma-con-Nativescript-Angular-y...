# Tarea NativeScript + Express + Settings + Redux

Proyecto de ejemplo para cumplir:
- API Express con GET y filtro por querystring.
- App Angular/NativeScript con búsqueda por HTTP desde un Service.
- Configuración de URL Ngrok.
- Settings con nombre de usuario persistente usando ApplicationSettings.
- Favoritos.
- Botón "Leer ahora" usando Redux/NgRx Store.
- Pantalla principal que muestra reactivamente los elementos marcados para leer ahora.

## Pasos

### 1. Instalar dependencias
```bash
npm install
```

### 2. Ejecutar API Express
```bash
npm run api
```

La API queda en:
```txt
http://localhost:3000/api/articulos
http://localhost:3000/api/articulos?q=angular
```

### 3. Usar Ngrok
```bash
ngrok http 3000
```

Copiar la URL HTTPS de Ngrok y pegarla en:

```txt
src/app/config/api.config.ts
```

Ejemplo:
```ts
export const API_CONFIG = {
  API_URL: 'https://TU-NGROK.ngrok-free.app'
};
```

### 4. Ejecutar app NativeScript
```bash
ns run android
```

## Nota
Este proyecto está armado como base funcional para VS Code y NativeScript Angular.
