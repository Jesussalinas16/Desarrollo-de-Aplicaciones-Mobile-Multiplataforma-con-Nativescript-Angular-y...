const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const articulos = [
  { id: 1, titulo: 'Introducción a Angular', categoria: 'Web', autor: 'Carlos Mejía' },
  { id: 2, titulo: 'NativeScript con Angular', categoria: 'Mobile', autor: 'Ana López' },
  { id: 3, titulo: 'Uso de Redux en aplicaciones móviles', categoria: 'Estado', autor: 'Luis Pérez' },
  { id: 4, titulo: 'Servicios HTTP en Angular', categoria: 'Web', autor: 'María Santos' },
  { id: 5, titulo: 'Persistencia local con AppSettings', categoria: 'Mobile', autor: 'José Rivera' },
  { id: 6, titulo: 'Express creando Webservices', categoria: 'Backend', autor: 'Nelson Díaz' }
];

app.get('/api/articulos', (req, res) => {
  const q = (req.query.q || '').toLowerCase();

  const resultado = articulos.filter(a =>
    a.titulo.toLowerCase().includes(q) ||
    a.categoria.toLowerCase().includes(q) ||
    a.autor.toLowerCase().includes(q)
  );

  res.json(resultado);
});

app.listen(PORT, () => {
  console.log(`API Express corriendo en http://localhost:${PORT}`);
});
