import { Injectable } from '@angular/core';
import { ApplicationSettings } from '@nativescript/core';

@Injectable({
  providedIn: 'root'
})
export class SettingsService {
  private readonly KEY_USUARIO = 'nombreUsuario';

  guardarNombre(nombre: string): void {
    ApplicationSettings.setString(this.KEY_USUARIO, nombre);
  }

  obtenerNombre(): string {
    return ApplicationSettings.getString(this.KEY_USUARIO, 'Invitado');
  }
}
