import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Articulo } from '../models/articulo.model';
import { API_CONFIG } from '../config/api.config';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ArticulosService {

  constructor(private http: HttpClient) {}

  buscarArticulos(texto: string): Observable<Articulo[]> {
    return this.http.get<Articulo[]>(
      `${API_CONFIG.API_URL}/api/articulos?q=${encodeURIComponent(texto)}`
    );
  }
}
