import { Injectable } from '@angular/core';
import { Articulo } from '../models/articulo.model';

@Injectable({
  providedIn: 'root'
})
export class FavoritosService {
  private favoritos: Articulo[] = [];

  agregarFavorito(articulo: Articulo): void {
    const existe = this.favoritos.some(a => a.id === articulo.id);

    if (!existe) {
      this.favoritos.push(articulo);
    }
  }

  obtenerFavoritos(): Articulo[] {
    return this.favoritos;
  }
}
