export interface Articulo {
  id: number;
  titulo: string;
  categoria: string;
  autor: string;
}
