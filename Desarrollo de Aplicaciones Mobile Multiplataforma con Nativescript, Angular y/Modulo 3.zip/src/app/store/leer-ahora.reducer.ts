import { createReducer, on } from '@ngrx/store';
import { Articulo } from '../models/articulo.model';
import { agregarLeerAhora } from './leer-ahora.actions';

export interface LeerAhoraState {
  articulos: Articulo[];
}

export const initialState: LeerAhoraState = {
  articulos: []
};

export const leerAhoraReducer = createReducer(
  initialState,
  on(agregarLeerAhora, (state, { articulo }) => {
    const existe = state.articulos.some(a => a.id === articulo.id);

    if (existe) {
      return state;
    }

    return {
      ...state,
      articulos: [...state.articulos, articulo]
    };
  })
);
