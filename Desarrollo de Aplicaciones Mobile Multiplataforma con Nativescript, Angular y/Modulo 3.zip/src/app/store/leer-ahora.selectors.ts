import { createFeatureSelector, createSelector } from '@ngrx/store';
import { LeerAhoraState } from './leer-ahora.reducer';

export const selectLeerAhoraState =
  createFeatureSelector<LeerAhoraState>('leerAhora');

export const selectArticulosLeerAhora = createSelector(
  selectLeerAhoraState,
  state => state.articulos
);
