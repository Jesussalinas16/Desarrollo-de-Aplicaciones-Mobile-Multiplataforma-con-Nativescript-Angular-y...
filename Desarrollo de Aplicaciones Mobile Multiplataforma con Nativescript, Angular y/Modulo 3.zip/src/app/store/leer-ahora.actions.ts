import { createAction, props } from '@ngrx/store';
import { Articulo } from '../models/articulo.model';

export const agregarLeerAhora = createAction(
  '[Leer Ahora] Agregar',
  props<{ articulo: Articulo }>()
);
