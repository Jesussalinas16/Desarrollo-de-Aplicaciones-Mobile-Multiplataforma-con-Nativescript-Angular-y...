export const API_CONFIG = {
  // Pega aquí tu URL de Ngrok.
  // Ejemplo: 'https://abc123.ngrok-free.app'
  API_URL: 'http://10.0.2.2:3000'
};
