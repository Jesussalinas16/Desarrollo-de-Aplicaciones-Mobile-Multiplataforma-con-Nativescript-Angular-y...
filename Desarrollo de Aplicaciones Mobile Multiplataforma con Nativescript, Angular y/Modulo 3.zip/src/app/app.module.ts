import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { NativeScriptModule, NativeScriptHttpClientModule, NativeScriptFormsModule } from '@nativescript/angular';
import { NativeScriptRouterModule } from '@nativescript/angular';
import { StoreModule } from '@ngrx/store';

import { AppComponent } from './app.component';
import { HomeComponent } from './features/home/home.component';
import { BuscarComponent } from './features/buscar/buscar.component';
import { FavoritosComponent } from './features/favoritos/favoritos.component';
import { SettingsComponent } from './features/settings/settings.component';
import { leerAhoraReducer } from './store/leer-ahora.reducer';

const routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'buscar', component: BuscarComponent },
  { path: 'favoritos', component: FavoritosComponent },
  { path: 'settings', component: SettingsComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BuscarComponent,
    FavoritosComponent,
    SettingsComponent
  ],
  imports: [
    NativeScriptModule,
    NativeScriptFormsModule,
    NativeScriptHttpClientModule,
    NativeScriptRouterModule.forRoot(routes),
    StoreModule.forRoot({ leerAhora: leerAhoraReducer })
  ],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule {}
