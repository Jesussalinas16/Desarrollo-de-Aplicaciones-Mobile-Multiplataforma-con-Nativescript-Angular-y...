import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { Articulo } from '../../models/articulo.model';
import { selectArticulosLeerAhora } from '../../store/leer-ahora.selectors';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'ns-home',
  templateUrl: './home.component.html'
})
export class HomeComponent {
  nombreUsuario = '';
  leerAhora$: Observable<Articulo[]>;

  constructor(
    private store: Store,
    private settingsService: SettingsService
  ) {
    this.nombreUsuario = this.settingsService.obtenerNombre();
    this.leerAhora$ = this.store.select(selectArticulosLeerAhora);
  }
}
