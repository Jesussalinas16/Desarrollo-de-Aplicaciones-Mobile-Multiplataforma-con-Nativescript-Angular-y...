import { Component } from '@angular/core';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'ns-settings',
  templateUrl: './settings.component.html'
})
export class SettingsComponent {
  nombre = '';

  constructor(private settingsService: SettingsService) {
    this.nombre = this.settingsService.obtenerNombre();
  }

  guardar(): void {
    this.settingsService.guardarNombre(this.nombre);
  }
}
