import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { FavoritosService } from '../../services/favoritos.service';
import { Articulo } from '../../models/articulo.model';
import { agregarLeerAhora } from '../../store/leer-ahora.actions';

@Component({
  selector: 'ns-favoritos',
  templateUrl: './favoritos.component.html'
})
export class FavoritosComponent {
  favoritos: Articulo[] = [];

  constructor(
    private favoritosService: FavoritosService,
    private store: Store
  ) {}

  ngOnInit(): void {
    this.favoritos = this.favoritosService.obtenerFavoritos();
  }

  leerAhora(articulo: Articulo): void {
    this.store.dispatch(agregarLeerAhora({ articulo }));
  }
}
