import { Component } from '@angular/core';
import { ArticulosService } from '../../services/articulos.service';
import { FavoritosService } from '../../services/favoritos.service';
import { Articulo } from '../../models/articulo.model';

@Component({
  selector: 'ns-buscar',
  templateUrl: './buscar.component.html'
})
export class BuscarComponent {
  textoBusqueda = '';
  articulos: Articulo[] = [];

  constructor(
    private articulosService: ArticulosService,
    private favoritosService: FavoritosService
  ) {}

  buscar(): void {
    this.articulosService.buscarArticulos(this.textoBusqueda)
      .subscribe(resultado => {
        this.articulos = resultado;
      });
  }

  guardarFavorito(articulo: Articulo): void {
    this.favoritosService.agregarFavorito(articulo);
  }
}
