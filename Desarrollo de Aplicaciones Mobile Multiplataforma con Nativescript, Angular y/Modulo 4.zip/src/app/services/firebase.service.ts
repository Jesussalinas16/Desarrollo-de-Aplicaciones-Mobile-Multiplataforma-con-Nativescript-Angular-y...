import { Injectable } from '@angular/core';
import { ToastDuration, Toasty } from '@nativescript/core/ui/toast';
import { Messaging } from '@nativescript/firebase-messaging';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {

  async iniciarFirebase(): Promise<void> {
    try {
      const messaging = new Messaging();

      await messaging.requestPermission();

      const token = await messaging.getToken();

      console.log('TOKEN FIREBASE ASIGNADO: ', token);

      messaging.onMessage((message: any) => {
        const texto = message?.notification?.title || 'Notificación recibida';

        new Toasty({
          text: texto,
          duration: ToastDuration.SHORT
        }).show();
      });

    } catch (error) {
      console.log('Error Firebase:', error);
    }
  }
}
