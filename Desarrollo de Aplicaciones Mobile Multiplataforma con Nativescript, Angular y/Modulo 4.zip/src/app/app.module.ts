import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { NativeScriptModule, NativeScriptFormsModule } from '@nativescript/angular';
import { NativeScriptRouterModule } from '@nativescript/angular';
import { StoreModule } from '@ngrx/store';

import { AppComponent } from './app.component';
import { HomeComponent } from './features/home/home.component';
import { CompartirComponent } from './features/compartir/compartir.component';
import { CamaraComponent } from './features/camara/camara.component';
import { MapaComponent } from './features/mapa/mapa.component';
import { favoritosReducer } from './store/favoritos.reducer';

const routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'compartir', component: CompartirComponent },
  { path: 'camara', component: CamaraComponent },
  { path: 'mapa', component: MapaComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CompartirComponent,
    CamaraComponent,
    MapaComponent
  ],
  imports: [
    NativeScriptModule,
    NativeScriptFormsModule,
    NativeScriptRouterModule.forRoot(routes),
    StoreModule.forRoot({ favoritos: favoritosReducer })
  ],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule {}
