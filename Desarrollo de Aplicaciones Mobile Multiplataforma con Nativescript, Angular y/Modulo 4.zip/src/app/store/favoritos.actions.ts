import { createAction, props } from '@ngrx/store';

export interface Favorito {
  id: number;
  nombre: string;
}

export const agregarFavorito = createAction(
  '[Favoritos] Agregar',
  props<{ favorito: Favorito }>()
);
