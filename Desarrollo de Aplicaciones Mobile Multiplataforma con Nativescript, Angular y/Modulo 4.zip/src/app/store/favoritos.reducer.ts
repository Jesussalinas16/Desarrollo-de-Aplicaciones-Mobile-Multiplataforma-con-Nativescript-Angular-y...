import { createReducer, on } from '@ngrx/store';
import { agregarFavorito, Favorito } from './favoritos.actions';

export interface FavoritosState {
  favoritos: Favorito[];
}

export const initialState: FavoritosState = {
  favoritos: []
};

export const favoritosReducer = createReducer(
  initialState,
  on(agregarFavorito, (state, { favorito }) => ({
    ...state,
    favoritos: [...state.favoritos, favorito]
  }))
);
