import { favoritosReducer, initialState } from './favoritos.reducer';
import { agregarFavorito } from './favoritos.actions';

describe('favoritosReducer', () => {

  it('debe agregar un favorito al estado', () => {
    const action = agregarFavorito({
      favorito: {
        id: 1,
        nombre: 'Prueba'
      }
    });

    const state = favoritosReducer(initialState, action);

    expect(state.favoritos.length).toBe(1);
    expect(state.favoritos[0].nombre).toBe('Prueba');
  });

});
