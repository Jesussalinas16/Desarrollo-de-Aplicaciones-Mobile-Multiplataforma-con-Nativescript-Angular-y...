import { Component } from '@angular/core';
import { RouterExtensions } from '@nativescript/angular';
import { FirebaseService } from './services/firebase.service';

@Component({
  selector: 'ns-app',
  templateUrl: './app.component.html'
})
export class AppComponent {

  constructor(
    private router: RouterExtensions,
    private firebaseService: FirebaseService
  ) {
    this.firebaseService.iniciarFirebase();
  }

  navegar(ruta: string): void {
    this.router.navigate([ruta]);
  }
}
