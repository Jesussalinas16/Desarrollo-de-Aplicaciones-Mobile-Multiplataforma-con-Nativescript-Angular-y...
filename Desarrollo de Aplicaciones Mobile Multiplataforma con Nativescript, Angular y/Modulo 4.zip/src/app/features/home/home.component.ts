import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { agregarFavorito } from '../../store/favoritos.actions';

@Component({
  selector: 'ns-home',
  templateUrl: './home.component.html'
})
export class HomeComponent {

  constructor(private store: Store) {}

  probarRedux(): void {
    this.store.dispatch(agregarFavorito({
      favorito: {
        id: 1,
        nombre: 'Elemento de prueba desde Home'
      }
    }));
  }
}
