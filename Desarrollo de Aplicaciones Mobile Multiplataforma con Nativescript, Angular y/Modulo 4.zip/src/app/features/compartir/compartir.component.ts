import { Component } from '@angular/core';
import { shareText, shareImage } from '@nativescript/social-share';
import { ImageSource } from '@nativescript/core';

@Component({
  selector: 'ns-compartir',
  templateUrl: './compartir.component.html'
})
export class CompartirComponent {

  compartirTexto(): void {
    shareText('Hola, este texto fue compartido desde NativeScript.');
  }

  async compartirImagen(): Promise<void> {
    const imagen = await ImageSource.fromResource('icono_compartir');

    if (imagen) {
      shareImage(imagen, 'Imagen compartida desde NativeScript');
    }
  }
}
