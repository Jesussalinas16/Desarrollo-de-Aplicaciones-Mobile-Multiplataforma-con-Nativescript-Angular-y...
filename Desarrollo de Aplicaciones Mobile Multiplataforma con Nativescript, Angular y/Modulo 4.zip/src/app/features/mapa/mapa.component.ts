import { Component } from '@angular/core';
import { MapReadyEvent, Marker, Position } from '@nativescript/google-maps';

@Component({
  selector: 'ns-mapa',
  templateUrl: './mapa.component.html'
})
export class MapaComponent {

  onMapReady(args: MapReadyEvent): void {
    const map = args.map;

    const posicion = Position.positionFromLatLng(14.0723, -87.1921);

    map.cameraPosition = {
      target: posicion,
      zoom: 14
    };

    const marker = new Marker();
    marker.position = posicion;
    marker.title = 'Tegucigalpa';
    marker.snippet = 'Marker personalizado en el mapa';

    map.addMarker(marker);
  }
}
