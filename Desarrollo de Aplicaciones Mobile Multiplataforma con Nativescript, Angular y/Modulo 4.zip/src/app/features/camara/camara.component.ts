import { Component } from '@angular/core';
import { takePicture, requestPermissions } from '@nativescript/camera';
import { ImageAsset, ImageSource } from '@nativescript/core';
import { shareImage } from '@nativescript/social-share';

@Component({
  selector: 'ns-camara',
  templateUrl: './camara.component.html'
})
export class CamaraComponent {
  foto: ImageAsset | null = null;
  fotoSource: ImageSource | null = null;

  async tomarFoto(): Promise<void> {
    await requestPermissions();

    this.foto = await takePicture({
      width: 300,
      height: 300,
      keepAspectRatio: true,
      saveToGallery: false
    });

    this.fotoSource = await ImageSource.fromAsset(this.foto);
  }

  compartirFoto(): void {
    if (this.fotoSource) {
      shareImage(this.fotoSource, 'Foto tomada con la cámara');
    }
  }
}
