# Proyecto NativeScript - Capacidades nativas + pruebas

Este proyecto base incluye lo que pide la tarea:

- Firebase configurado con archivo `google-services.json` de ejemplo.
- Servicio para obtener token de Firebase.
- Toast para mostrar notificaciones entrantes.
- Social Share para compartir texto.
- Social Share para compartir imagen.
- Cámara para tomar fotografías.
- Imagen tomada con cámara lista para compartir.
- Google Maps con marker.
- Redux/NgRx reducer.
- Suite Jasmine para probar reducer.
- Karma + JUnit Reporter configurado.

## Importante

Debes reemplazar estos archivos con los tuyos reales:

```txt
App_Resources/Android/google-services.json
App_Resources/Android/src/main/AndroidManifest.xml
```

También debes colocar tu API KEY real de Google Maps en el `AndroidManifest.xml`.

## Instalar

```bash
npm install
```

## Ejecutar Android

```bash
ns run android
```

## Ejecutar tests

```bash
npm test
```

Después de correr las pruebas, se genera el reporte en:

```txt
test-results/junit-test-results.xml
```
